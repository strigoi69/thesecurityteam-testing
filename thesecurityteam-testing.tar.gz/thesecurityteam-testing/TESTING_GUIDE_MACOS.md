# API.thesecurityteam.rocks Vulnerability Testing Guide (macOS)

## Overview
This comprehensive testing suite targets `api.thesecurityteam.rocks` for the **myapp-mbb-og** Bugcrowd program, focusing on four critical vulnerability categories:

1. **Server-Side Injection** (SQL, Command, Template)
2. **Insecure Data Storage** 
3. **Cross-Site Scripting (XSS)**
4. **Unvalidated Redirects**

## macOS Setup Instructions

### Prerequisites
```bash
# Install Homebrew (if not installed)
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

# Verify curl is available
curl --version
```

### Initial Setup
```bash
# Make scripts executable
chmod +x *.sh

# Run setup script
./SETUP_MACOS.sh
```

## Testing Scripts Overview

### 1. THESECURITYTEAM_EXHAUSTIVE_ANALYSIS.sh
**Purpose**: Initial reconnaissance and information gathering
**Tests**:
- HTTP methods enumeration (GET, POST, PUT, DELETE, PATCH)
- Header manipulation bypasses (X-Forwarded-For, Host, X-Original-URL)
- Path traversal attempts (/../, encoding bypasses)
- Directory enumeration
- Technology stack fingerprinting
- Security headers analysis

### 2. THESECURITYTEAM_SERVER_SIDE_INJECTION.sh
**Purpose**: Server-side injection vulnerability testing
**Tests**:
- **SQL Injection**: `' OR '1'='1`, UNION SELECT, time-based blind SQL
- **Command Injection**: `; whoami`, `| id`, `&& uname -a`
- **Template Injection**: `{{7*7}}`, `${7*7}`, `{{config.__class__.__init__.__globals__['os'].popen('whoami').read()}}`
- **NoSQL Injection**: MongoDB-style payload testing
- **LDAP Injection**: Directory service testing

### 3. THESECURITYTEAM_INSECURE_DATA_STORAGE.sh
**Purpose**: Detect insecure data storage and exposure
**Tests**:
- Directory traversal for config files (/etc/passwd, web.config)
- Backup file enumeration (.bak, .old, .backup)
- Log file exposure
- Database file discovery
- Credentials in source code
- API key exposure in responses

### 4. THESECURITYTEAM_XSS_TESTING.sh
**Purpose**: Cross-Site Scripting vulnerability detection
**Tests**:
- **Reflected XSS**: Basic `<script>alert('XSS')</script>`
- **POST-based XSS**: JSON and form data injection
- **DOM-based XSS**: URL fragment injection
- **Blind XSS**: External payload delivery
- **Encoding bypasses**: URL encoding, HTML entities
- **Special characters**: Null bytes, Unicode

### 5. THESECURITYTEAM_UNVALIDATED_REDIRECTS.sh
**Purpose**: Open redirect vulnerability testing
**Tests**:
- **Basic redirects**: `?next=http://attacker.com`
- **Login redirects**: POST data with redirect parameters
- **Protocol injection**: `javascript:`, `data:`, `file:`
- **Header manipulation**: Location header injection
- **Relative path bypass**: `//attacker.com`, encoding
- **OAuth/SSO redirects**: Authorization flow testing

### 6. THESECURITYTEAM_COMPREHENSIVE_TESTING.sh
**Purpose**: Master script running all tests sequentially
**Features**:
- Automated execution of all testing phases
- Results aggregation and analysis
- Comprehensive reporting
- Potential vulnerability flagging

## Usage Instructions

### Option 1: Run Individual Tests
```bash
# Make executable (if not done already)
chmod +x THESECURITYTEAM_SERVER_SIDE_INJECTION.sh

# Run specific vulnerability test
./THESECURITYTEAM_SERVER_SIDE_INJECTION.sh

# Run XSS testing
./THESECURITYTEAM_XSS_TESTING.sh
```

### Option 2: Run Comprehensive Testing (Recommended)
```bash
# Run all tests in sequence
./THESECURITYTEAM_COMPREHENSIVE_TESTING.sh
```

### Option 3: Custom Testing Workflow
```bash
# 1. Start with reconnaissance
./THESECURITYTEAM_EXHAUSTIVE_ANALYSIS.sh

# 2. Based on findings, run targeted tests
./THESECURITYTEAM_SERVER_SIDE_INJECTION.sh
./THESECURITYTEAM_XSS_TESTING.sh

# 3. Analyze results manually
cat COMPREHENSIVE_REPORT.txt
```

## Output Files and Analysis

### Generated Files Pattern
- `*_test*.txt`: Raw test results
- `*_indicators.txt`: Filtered vulnerability indicators
- `COMPREHENSIVE_REPORT.txt`: Final analysis report
- `potential_vulnerabilities.txt`: Quick vulnerability summary
- `results_api_thesecurityteam_rocks/`: All test outputs organized

### Key Indicators to Look For

#### SQL Injection
- Database error messages (MySQL, PostgreSQL, Oracle)
- `mysql_fetch_array()`, `pg_sleep()`, `WAITFOR DELAY`
- Boolean-based indicators in responses

#### Command Injection
- Command output in responses (`whoami`, `id`, `uname`)
- File system traversal results
- Process enumeration

#### XSS
- JavaScript execution (`alert()` calls)
- Script tag reflection
- DOM manipulation results

#### Unvalidated Redirects
- `Location:` headers pointing to external domains
- 3xx responses (301, 302, 307, 308) to attacker-controlled URLs
- Protocol injection in redirects

#### Insecure Data Storage
- Sensitive file contents (/etc/passwd, config files)
- Database connection strings
- API keys and secrets
- Backup file discovery

## macOS-Specific Features

### Automatic Setup
- `SETUP_MACOS.sh` handles permissions and environment setup
- Checks for curl installation via Homebrew
- Creates proper directory structure

### Shell Compatibility
- All scripts use bash shell syntax
- Compatible with macOS default shell (zsh/bash)
- No Windows-specific commands

### Results Organization
```bash
results_api_thesecurityteam_rocks/     # Main results directory
├── sql_injection_test*.txt            # SQL injection results
├── xss_test*.txt                      # XSS testing results
├── redirect_test*.txt                 # Redirect testing results
├── COMPREHENSIVE_REPORT.txt           # Final analysis
└── potential_vulnerabilities.txt      # Quick summary
```

## Testing Methodology

### Phase 1: Reconnaissance
- Map attack surface and entry points
- Identify technology stack
- Enumerate HTTP methods and endpoints

### Phase 2: Vulnerability Testing
- Systematic injection testing
- Parameter manipulation
- Header exploitation

### Phase 3: Results Analysis
- Cross-reference findings
- Validate potential vulnerabilities
- Generate evidence for reporting

## Bugcrowd Submission Guidelines

### Evidence Requirements
1. **Proof of Concept**: Demonstrate the vulnerability
2. **Impact Assessment**: Explain potential damage
3. **Reproduction Steps**: Clear, reproducible steps
4. **Screenshots**: Visual evidence where applicable

### Vulnerability Classification
- **Server-Side Injection**: P1-P3 (Critical to Medium)
- **Insecure Data Storage**: P1-P4 (Critical to Medium)
- **XSS**: P2-P4 (High to Medium)
- **Unvalidated Redirects**: P3-P4 (Medium to Low)

### Documentation Best Practices
- Use professional language
- Include technical details
- Provide remediation suggestions
- Maintain consistent formatting

## Important Notes

### Legal and Ethical Testing
- Only test authorized targets
- Respect rate limits
- Avoid DoS conditions
- Document all testing activities

### Technical Considerations
- macOS-compatible shell scripts
- Uses curl for HTTP requests
- Timeout protection (10-30 seconds)
- Error handling for network issues

### Optimization Tips
- Run reconnaissance first to identify interesting endpoints
- Focus testing on dynamic parameters
- Pay attention to error messages and responses
- Use results to guide deeper testing

## Troubleshooting

### Common Issues
1. **Permission denied**: Run `chmod +x *.sh`
2. **curl not found**: Install via `brew install curl`
3. **Connection timeouts**: Network issues or WAF protection
4. **Empty responses**: Endpoint requires authentication
5. **403 errors**: Access restrictions or rate limiting

### Solutions
- Increase timeout values in scripts
- Test different authentication methods
- Use proxy tools for detailed analysis
- Verify network connectivity
- Check target accessibility

## Quick Commands Reference

```bash
# Setup environment
./SETUP_MACOS.sh

# Run comprehensive testing
./THESECURITYTEAM_COMPREHENSIVE_TESTING.sh

# Check results
cat COMPREHENSIVE_REPORT.txt

# Search for specific vulnerabilities
grep -i "sql\|mysql\|alert" *.txt

# Clean up results
rm -rf results_api_thesecurityteam_rocks/
```

---

**Created for**: Vlad Strigoi - Bugcrowd Bug Bounty Hunter  
**Target**: api.thesecurityteam.rocks  
**Program**: myapp-mbb-og  
**Platform**: macOS/Linux  
**Date**: 2025-12-15  
