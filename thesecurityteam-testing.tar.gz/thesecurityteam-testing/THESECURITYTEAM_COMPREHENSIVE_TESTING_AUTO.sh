#!/bin/bash
echo "======================================"
echo "COMPREHENSIVE VULNERABILITY TESTING AUTO"
echo "TARGET: api.thesecurityteam.rocks"
echo "PROGRAM: myapp-mbb-og"
echo "======================================"
echo

TARGET="api.thesecurityteam.rocks"
PROGRAM="myapp-mbb-og"

echo "[INFO] Starting comprehensive vulnerability assessment..."
echo "[TARGET] $TARGET"
echo "[PROGRAM] $PROGRAM"
echo "[TIME] $(date)"
echo

# Create results directory
RESULTS_DIR="results_${TARGET//./_}"
if [ ! -d "$RESULTS_DIR" ]; then
    mkdir "$RESULTS_DIR"
fi

cd "$RESULTS_DIR"
echo "[SETUP] Created results directory: $RESULTS_DIR"
echo

# Phase 1: Reconnaissance and Basic Testing
echo "[PHASE 1] Starting reconnaissance and basic testing..."
echo "[ACTION] Running THESECURITYTEAM_EXHAUSTIVE_ANALYSIS_AUTO.sh"
bash ../THESECURITYTEAM_EXHAUSTIVE_ANALYSIS_AUTO.sh
echo "[COMPLETED] Phase 1 - Reconnaissance"
echo

# Phase 2: Server-Side Injection Testing
echo "[PHASE 2] Starting Server-Side Injection testing..."
echo "[ACTION] Running THESECURITYTEAM_SERVER_SIDE_INJECTION_AUTO.sh"
bash ../THESECURITYTEAM_SERVER_SIDE_INJECTION_AUTO.sh
echo "[COMPLETED] Phase 2 - Server-Side Injection"
echo

# Phase 3: Insecure Data Storage Testing
echo "[PHASE 3] Starting Insecure Data Storage testing..."
echo "[ACTION] Running THESECURITYTEAM_INSECURE_DATA_STORAGE_AUTO.sh"
bash ../THESECURITYTEAM_INSECURE_DATA_STORAGE_AUTO.sh
echo "[COMPLETED] Phase 3 - Insecure Data Storage"
echo

# Phase 4: XSS Testing
echo "[PHASE 4] Starting XSS testing..."
echo "[ACTION] Running THESECURITYTEAM_XSS_TESTING_AUTO.sh"
bash ../THESECURITYTEAM_XSS_TESTING_AUTO.sh
echo "[COMPLETED] Phase 4 - XSS Testing"
echo

# Phase 5: Unvalidated Redirects Testing
echo "[PHASE 5] Starting Unvalidated Redirects testing..."
echo "[ACTION] Running THESECURITYTEAM_UNVALIDATED_REDIRECTS_AUTO.sh"
bash ../THESECURITYTEAM_UNVALIDATED_REDIRECTS_AUTO.sh
echo "[COMPLETED] Phase 5 - Unvalidated Redirects"
echo

# Phase 6: Results Analysis
echo "[PHASE 6] Analyzing all results..."

echo "[ANALYSIS] Creating comprehensive analysis report..."

# Combine all results
echo "[COMBINING] All testing results..."
cp ../*test*.txt . 2>/dev/null || true

# Create summary report
echo "Vulnerability Assessment Summary Report" > COMPREHENSIVE_REPORT.txt
echo "===============================================" >> COMPREHENSIVE_REPORT.txt
echo "Target: $TARGET" >> COMPREHENSIVE_REPORT.txt
echo "Program: $PROGRAM" >> COMPREHENSIVE_REPORT.txt
echo "Date: $(date)" >> COMPREHENSIVE_REPORT.txt
echo "" >> COMPREHENSIVE_REPORT.txt

echo "[SECTION 1] SQL Injection Indicators" >> COMPREHENSIVE_REPORT.txt
echo "==========================================" >> COMPREHENSIVE_REPORT.txt
grep -i "sql\|mysql\|postgresql\|oracle\|syntax error\|mysql_fetch\|pg_sleep\|sleep(" sql_injection_test*.txt >> COMPREHENSIVE_REPORT.txt 2>/dev/null
echo "" >> COMPREHENSIVE_REPORT.txt

echo "[SECTION 2] Command Injection Indicators" >> COMPREHENSIVE_REPORT.txt
echo "===========================================" >> COMPREHENSIVE_REPORT.txt
grep -i "whoami\|id\|uname\|pwd\|cat /etc/passwd\|dir\|system32" command_injection_test*.txt >> COMPREHENSIVE_REPORT.txt 2>/dev/null
echo "" >> COMPREHENSIVE_REPORT.txt

echo "[SECTION 3] Template Injection Indicators" >> COMPREHENSIVE_REPORT.txt
echo "===========================================" >> COMPREHENSIVE_REPORT.txt
grep -i "{{.*}}\|{%%.*%%}\|\${.*}" template_injection_test*.txt >> COMPREHENSIVE_REPORT.txt 2>/dev/null
echo "" >> COMPREHENSIVE_REPORT.txt

echo "[SECTION 4] XSS Indicators" >> COMPREHENSIVE_REPORT.txt
echo "================================" >> COMPREHENSIVE_REPORT.txt
grep -i "alert\|<script>\|javascript:\|onerror=\|onload=" xss_test*.txt >> COMPREHENSIVE_REPORT.txt 2>/dev/null
echo "" >> COMPREHENSIVE_REPORT.txt

echo "[SECTION 5] Redirect Vulnerabilities" >> COMPREHENSIVE_REPORT.txt
echo "=====================================" >> COMPREHENSIVE_REPORT.txt
grep -i "Location: http" redirect_test*.txt | grep -v "thesecurityteam.rocks" >> COMPREHENSIVE_REPORT.txt 2>/dev/null
echo "" >> COMPREHENSIVE_REPORT.txt

echo "[SECTION 6] Security Headers Analysis" >> COMPREHENSIVE_REPORT.txt
echo "=====================================" >> COMPREHENSIVE_REPORT.txt
grep -i "X-Frame-Options\|Content-Security-Policy\|X-XSS-Protection\|Strict-Transport-Security" *test*.txt >> COMPREHENSIVE_REPORT.txt 2>/dev/null
echo "" >> COMPREHENSIVE_REPORT.txt

echo "[SECTION 7] Error Messages and Stack Traces" >> COMPREHENSIVE_REPORT.txt
echo "===========================================" >> COMPREHENSIVE_REPORT.txt
grep -i "error\|exception\|stack trace\|at " *test*.txt >> COMPREHENSIVE_REPORT.txt 2>/dev/null
echo "" >> COMPREHENSIVE_REPORT.txt

echo "[SECTION 8] Sensitive Information Disclosure" >> COMPREHENSIVE_REPORT.txt
echo "=============================================" >> COMPREHENSIVE_REPORT.txt
grep -i "password\|secret\|key\|token\|api_key\|private" *test*.txt >> COMPREHENSIVE_REPORT.txt 2>/dev/null
echo "" >> COMPREHENSIVE_REPORT.txt

echo "Testing completed. Review COMPREHENSIVE_REPORT.txt for findings."
echo

# Create quick summary
echo "[QUICK SUMMARY] Potential vulnerabilities found:"
echo "================================================"
grep -i "alert\|<script>\|sql\|mysql\|postgresql\|whoami\|id\|uname" *test*.txt > potential_vulnerabilities.txt 2>/dev/null
if [ -s potential_vulnerabilities.txt ]; then
    echo "[WARNING] Potential vulnerabilities detected!"
    cat potential_vulnerabilities.txt
else
    echo "[INFO] No obvious vulnerabilities detected in initial analysis"
fi

echo
echo "======================================"
echo "VULNERABILITY ASSESSMENT COMPLETED"
echo "======================================"
echo "Results saved in: $RESULTS_DIR/"
echo "Main report: COMPREHENSIVE_REPORT.txt"
echo "[TIME] $(date)"
echo

# Return to original directory
cd ..
echo "All files copied to $RESULTS_DIR/ for analysis"
echo "Open COMPREHENSIVE_REPORT.txt for detailed findings"