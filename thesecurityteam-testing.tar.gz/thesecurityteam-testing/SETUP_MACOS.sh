#!/bin/bash
echo "======================================"
echo "SETTING UP BUG BOUNTY TESTING TOOLS"
echo "TARGET: api.thesecurityteam.rocks"
echo "======================================"
echo

echo "[INFO] Setting up testing environment for macOS..."
echo "[TIME] $(date)"
echo

# Make all shell scripts executable
echo "[SETUP] Making scripts executable..."
chmod +x *.sh
echo "✓ All .sh scripts are now executable"
echo

# Install curl if not available
if ! command -v curl &> /dev/null; then
    echo "[WARNING] curl not found. Installing via Homebrew..."
    if command -v brew &> /dev/null; then
        brew install curl
        echo "✓ curl installed successfully"
    else
        echo "[ERROR] Homebrew not found. Please install curl manually."
        echo "Visit: https://brew.sh"
        exit 1
    fi
else
    echo "✓ curl is already available"
fi

# Create testing directory structure
echo "[SETUP] Creating testing directory structure..."
mkdir -p results_api_thesecurityteam_rocks
mkdir -p evidence
mkdir -p reports
echo "✓ Directory structure created"
echo

# Verify target accessibility
echo "[VERIFICATION] Testing target accessibility..."
if curl -s -k --connect-timeout 10 "https://api.thesecurityteam.rocks/" > /dev/null; then
    echo "✓ Target is accessible"
else
    echo "[WARNING] Target may not be accessible or has protection"
    echo "Manual verification recommended"
fi
echo

# Display usage instructions
echo "======================================"
echo "SETUP COMPLETED SUCCESSFULLY"
echo "======================================"
echo
echo "Available Testing Scripts:"
echo "1. THESECURITYTEAM_EXHAUSTIVE_ANALYSIS.sh - Reconnaissance"
echo "2. THESECURITYTEAM_SERVER_SIDE_INJECTION.sh - SQL/Command/Template injection"
echo "3. THESECURITYTEAM_INSECURE_DATA_STORAGE.sh - Data storage vulnerabilities"
echo "4. THESECURITYTEAM_XSS_TESTING.sh - Cross-Site Scripting"
echo "5. THESECURITYTEAM_UNVALIDATED_REDIRECTS.sh - Open redirects"
echo "6. THESECURITYTEAM_COMPREHENSIVE_TESTING.sh - Run all tests"
echo
echo "Usage Examples:"
echo "# Run specific test"
echo "./THESECURITYTEAM_XSS_TESTING.sh"
echo
echo "# Run comprehensive testing"
echo "./THESECURITYTEAM_COMPREHENSIVE_TESTING.sh"
echo
echo "Results will be saved in:"
echo "- results_api_thesecurityteam_rocks/ - All test outputs"
echo "- COMPREHENSIVE_REPORT.txt - Analysis summary"
echo
echo "Target: api.thesecurityteam.rocks"
echo "Program: myapp-mbb-og (Bugcrowd)"
echo
echo "======================================"
read -p "Press Enter to continue..."