#!/bin/bash
echo "======================================"
echo "TESTING UNVALIDATED REDIRECTS - api.thesecurityteam.rocks"
echo "======================================"
echo

TARGET="api.thesecurityteam.rocks"
PROTOCOL="https"
FULL_URL="https://api.thesecurityteam.rocks"

echo "[INFO] Starting Unvalidated Redirects testing..."
echo "[TARGET] $FULL_URL"
echo "[TIME] $(date)"
echo

# Test 1: Basic redirect parameter testing
echo "[TEST 1] Testing redirect parameters with external domains..."
curl -s -k -X GET "$PROTOCOL://$TARGET/?next=http://attacker.com" -I --connect-timeout 10 --max-time 30 > redirect_test1.txt
curl -s -k -X GET "$PROTOCOL://$TARGET/?redirect=http://evil.com" -I --connect-timeout 10 --max-time 30 >> redirect_test1.txt
echo "[RESULT] Check redirect_test1.txt for 3xx redirects to external domains"
echo

# Test 2: Return URL testing
echo "[TEST 2] Testing return/returnUrl parameters..."
curl -s -k -X GET "$PROTOCOL://$TARGET/?return=http://malicious-site.com" -I --connect-timeout 10 --max-time 30 > redirect_test2.txt
curl -s -k -X GET "$PROTOCOL://$TARGET/?returnUrl=http://phishing-site.com" -I --connect-timeout 10 --max-time 30 >> redirect_test2.txt
echo "[RESULT] Check redirect_test2.txt for return URL vulnerabilities"
echo

# Test 3: Login/logout redirect testing
echo "[TEST 3] Testing login and logout redirects..."
curl -s -k -X POST "$PROTOCOL://$TARGET/login" -d "username=test&password=test&redirect=http://attacker.com" -I --connect-timeout 10 --max-time 30 > redirect_test3.txt
curl -s -k -X GET "$PROTOCOL://$TARGET/logout?redirect=http://evil.com" -I --connect-timeout 10 --max-time 30 >> redirect_test3.txt
echo "[RESULT] Check redirect_test3.txt for login/logout redirect vulnerabilities"
echo

# Test 4: URL parameter variations
echo "[TEST 4] Testing various URL parameter names..."
curl -s -k -X GET "$PROTOCOL://$TARGET/?url=http://malicious.com" -I --connect-timeout 10 --max-time 30 > redirect_test4.txt
curl -s -k -X GET "$PROTOCOL://$TARGET/?continue=http://bad-site.com" -I --connect-timeout 10 --max-time 30 >> redirect_test4.txt
curl -s -k -X GET "$PROTOCOL://$TARGET/?forward=http://phishing.com" -I --connect-timeout 10 --max-time 30 >> redirect_test4.txt
echo "[RESULT] Check redirect_test4.txt for various redirect parameters"
echo

# Test 5: Protocol injection (javascript:, data:, file:)
echo "[TEST 5] Testing dangerous protocol injection..."
curl -s -k -X GET "$PROTOCOL://$TARGET/?next=javascript:alert('XSS')" -I --connect-timeout 10 --max-time 30 > redirect_test5.txt
curl -s -k -X GET "$PROTOCOL://$TARGET/?redirect=data:text/html,<script>alert('XSS')</script>" -I --connect-timeout 10 --max-time 30 >> redirect_test5.txt
curl -s -k -X GET "$PROTOCOL://$TARGET/?url=file:///etc/passwd" -I --connect-timeout 10 --max-time 30 >> redirect_test5.txt
echo "[RESULT] Check redirect_test5.txt for protocol injection attempts"
echo

# Test 6: Open redirect through header manipulation
echo "[TEST 6] Testing open redirects through headers..."
curl -s -k -X GET "$PROTOCOL://$TARGET/" -H "Location: http://attacker.com" -I --connect-timeout 10 --max-time 30 > redirect_test6.txt
curl -s -k -X GET "$PROTOCOL://$TARGET/" -H "X-Forwarded-Host: malicious.com" -I --connect-timeout 10 --max-time 30 >> redirect_test6.txt
curl -s -k -X GET "$PROTOCOL://$TARGET/" -H "X-Original-URL: http://evil.com" -I --connect-timeout 10 --max-time 30 >> redirect_test6.txt
echo "[RESULT] Check redirect_test6.txt for header-based redirects"
echo

# Test 7: Relative path bypass attempts
echo "[TEST 7] Testing relative path bypass..."
curl -s -k -X GET "$PROTOCOL://$TARGET/?next=//attacker.com" -I --connect-timeout 10 --max-time 30 > redirect_test7.txt
curl -s -k -X GET "$PROTOCOL://$TARGET/?redirect=\\attacker.com" -I --connect-timeout 10 --max-time 30 >> redirect_test7.txt
curl -s -k -X GET "$PROTOCOL://$TARGET/?url=%2F%2Fattacker.com" -I --connect-timeout 10 --max-time 30 >> redirect_test7.txt
echo "[RESULT] Check redirect_test7.txt for relative path bypass attempts"
echo

# Test 8: URL encoding bypass
echo "[TEST 8] Testing URL encoding bypass..."
curl -s -k -X GET "$PROTOCOL://$TARGET/?next=http%3A%2F%2Fattacker%2Ecom" -I --connect-timeout 10 --max-time 30 > redirect_test8.txt
curl -s -k -X GET "$PROTOCOL://$TARGET/?redirect=%68%74%74%70%3A%2F%2Fevil%2Ecom" -I --connect-timeout 10 --max-time 30 >> redirect_test8.txt
echo "[RESULT] Check redirect_test8.txt for encoded redirect attempts"
echo

# Test 9: Domain validation bypass
echo "[TEST 9] Testing domain validation bypass..."
curl -s -k -X GET "$PROTOCOL://$TARGET/?next=http://thesecurityteam.rocks.attacker.com" -I --connect-timeout 10 --max-time 30 > redirect_test9.txt
curl -s -k -X GET "$PROTOCOL://$TARGET/?redirect=http://thesecurityteam.rocks.evil.com" -I --connect-timeout 10 --max-time 30 >> redirect_test9.txt
curl -s -k -X GET "$PROTOCOL://$TARGET/?url=http://attacker.com.thesecurityteam.rocks" -I --connect-timeout 10 --max-time 30 >> redirect_test9.txt
echo "[RESULT] Check redirect_test9.txt for domain validation bypass"
echo

# Test 10: OAuth and SSO redirect testing
echo "[TEST 10] Testing OAuth and SSO redirects..."
curl -s -k -X GET "$PROTOCOL://$TARGET/oauth/authorize?redirect_uri=http://attacker.com" -I --connect-timeout 10 --max-time 30 > redirect_test10.txt
curl -s -k -X GET "$PROTOCOL://$TARGET/auth/callback?redirect=http://malicious.com" -I --connect-timeout 10 --max-time 30 >> redirect_test10.txt
curl -s -k -X GET "$PROTOCOL://$TARGET/sso/login?return_to=http://evil.com" -I --connect-timeout 10 --max-time 30 >> redirect_test10.txt
echo "[RESULT] Check redirect_test10.txt for OAuth/SSO redirect vulnerabilities"
echo

# Test 11: HTTP parameter pollution redirects
echo "[TEST 11] Testing HTTP parameter pollution for redirects..."
curl -s -k -X GET "$PROTOCOL://$TARGET/?redirect=http://good.com&redirect=http://evil.com" -I --connect-timeout 10 --max-time 30 > redirect_test11.txt
echo "[RESULT] Check redirect_test11.txt for parameter pollution redirects"
echo

# Test 12: Fragment-based redirects
echo "[TEST 12] Testing fragment-based redirects..."
curl -s -k -X GET "$PROTOCOL://$TARGET/?next=#http://evil.com" -I --connect-timeout 10 --max-time 30 > redirect_test12.txt
curl -s -k -X GET "$PROTOCOL://$TARGET/?redirect=#javascript:alert('XSS')" -I --connect-timeout 10 --max-time 30 >> redirect_test12.txt
echo "[RESULT] Check redirect_test12.txt for fragment-based redirects"
echo

echo "[COMPLETED] Unvalidated Redirects testing completed. Review all redirect_test*.txt files."
echo "[TIME] $(date)"
echo

# Analyze results for redirect indicators
echo "[ANALYSIS] Searching for redirect indicators in results..."
grep -i "Location:\|302\|301\|307\|308" *.txt > redirect_indicators.txt 2>/dev/null
if [ -s redirect_indicators.txt ]; then
    echo "[WARNING] Potential redirect vulnerabilities found! Check redirect_indicators.txt"
else
    echo "[INFO] No obvious redirect vulnerabilities detected"
fi

# Extract all Location headers to external domains
echo "[EXTRACTION] Extracting external redirects..."
grep -i "Location: http" *.txt | grep -v "thesecurityteam.rocks" > external_redirects.txt 2>/dev/null
if [ -s external_redirects.txt ]; then
    echo "[CRITICAL] External redirects found! Check external_redirects.txt"
else
    echo "[INFO] No external redirects detected"
fi

# Check for protocol injection
echo "[PROTOCOL CHECK] Checking for protocol injection..."
grep -i "Location: javascript:\|Location: data:\|Location: file:" *.txt > protocol_injection.txt 2>/dev/null
if [ -s protocol_injection.txt ]; then
    echo "[CRITICAL] Protocol injection found! Check protocol_injection.txt"
fi

echo

echo "Unvalidated Redirects testing phase completed successfully."